
<div class="toggle-menu menu-left"></div>

<nav class="menu">
	<ul>
		<li>Meierij</li>
		<li><a href="#time" class="smooth">Menukaart</a></li>
		<li><a href="#map" class="smooth">Gegevens</a></li>
		<li><a href="#door"class="smooth">Door ons</a></li>
	</ul>
	<div class="social">
	</div>
</nav>
<div class="meierijicon"><img src="img/intro.png"></div>

<!-- Left menu element-->
<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">
	<h3>Menu</h3>
	<a href="#time" class="smooth">Menukaart</a>
	<a href="#map" class="smooth">Gegevens</a>
	<a href="#door" class="smooth">Door ons</a>
</nav>
