<section class="brt menuholder fs" id="door">

  <article class="foodimage">
    <article class="tekst">
      <p>Asperges met boerenbeenham</p>
    </article>
  </article>

  <article class="foodimage">
    <article class="tekst">
      <p>Zalm tartaar</p>
    </article>
  </article>

  <article class="foodimage">
    <article class="tekst">
      <p>Verse kruiden</p>
    </article>
  </article>

  <article class="foodimage">
    <article class="tekst">
      <p>gado-gado met curry bites</p>
    </article>
  </article>

  <article class="foodimage">
    <article class="tekst">
      <p>Huisgemaakte kruiden pesto</p>
    </article>
  </article>

  <article class="foodimage">
    <article class="tekst">
      <p>Garnalen kroketjes</p>
    </article>
  </article>

  <article class="foodimage">
    <article class="tekst">
      <p>Tonijn salade</p>
    </article>
  </article>

  <article class="foodimage">
    <article class="tekst">
      <p>Fudge van pure chocolade</p>
    </article>
  </article>

  <article class="foodimage">
    <article class="tekst">
      <p>Water kerssoep</p>
    </article>
  </article>

  <article class="foodimage">
    <article class="tekst">
      <p>Ravioli met doperwten en munt</p>
    </article>
  </article>

  <article class="foodimage">
    <article class="tekst">
      <p>Lamscarree</p>
    </article>
  </article>

  <article class="foodimage">
    <article class="tekst">
      <p>Kaasfondue</p>
    </article>
  </article>

</section>
