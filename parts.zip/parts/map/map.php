<section class="brt">
  <div class="google_map">
    <iframe width="100%" height="100%" id="map" frameborder="0" style="border:0; pointer-events:none"src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2432.7085566736882!2d4.641771316026296!3d52.430078250641444!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c5efe882215761%3A0xa26b56a01009299f!2sRestaurant+De+Meierij!5e0!3m2!1snl!2snl!4v1448996859319"></iframe>
  </div>
</section>
